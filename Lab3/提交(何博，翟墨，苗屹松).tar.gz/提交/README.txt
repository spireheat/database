编译方式： g++ -o ucasdb database.cpp
运行方式： ./ucasdb name
运行环境： Linux
